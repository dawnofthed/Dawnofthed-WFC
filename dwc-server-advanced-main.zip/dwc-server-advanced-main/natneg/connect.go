package natneg

import (
	"dwc-server-advanced/common"
	"dwc-server-advanced/logging"
	"encoding/binary"
	"net"
	"time"

	"github.com/logrusorgru/aurora/v3"
)

func (session *NATNEGSession) sendConnectRequests(moduleName string) {
	for id, sender := range session.Clients {
		if !sender.isMapped() || sender.ConnectingIndex != id {
			continue
		}

		for destID, destination := range session.Clients {
			if id == destID || !destination.isMapped() || destination.ConnectingIndex != destID {
				continue
			}

			if _, hasResult := destination.Result[id]; hasResult {
				continue
			}

			logging.Notice(moduleName, "Exchange connect requests between", aurora.BrightCyan(id), "and", aurora.BrightCyan(destID))
			sender.ConnectingIndex = destID
			sender.ConnectAck = false
			destination.ConnectingIndex = id
			destination.ConnectAck = false

			go func(session *NATNEGSession, sender *NATNEGClient, destination *NATNEGClient) {
				for {
					if !session.Open {
						return
					}

					check := false

					if !destination.ConnectAck && destination.ConnectingIndex == sender.Index {
						check = true
						sender.sendConnectRequestPacket(natnegConn, destination, session.Version)
					}

					if !sender.ConnectAck && sender.ConnectingIndex == destination.Index {
						check = true
						destination.sendConnectRequestPacket(natnegConn, sender, session.Version)
					}

					if !check {
						return
					}

					time.Sleep(500 * time.Millisecond)
				}
			}(session, sender, destination)
		}
	}
}

func (client *NATNEGClient) sendConnectRequestPacket(conn net.PacketConn, destination *NATNEGClient, version byte) {
	connectHeader := createPacketHeader(version, NNConnectRequest, destination.Cookie)
	connectHeader = append(connectHeader, common.IPFormatBytes(client.ServerIP)...)
	_, port := common.IPFormatToInt(client.ServerIP)
	connectHeader = binary.BigEndian.AppendUint16(connectHeader, port)
	// Two bytes: "gotyourdata" and "finished"
	connectHeader = append(connectHeader, 0x42, 0x00)

	destIPAddr, err := net.ResolveUDPAddr("udp", destination.NegotiateIP)
	common.ShouldNotError(err)
	_, _ = conn.WriteTo(connectHeader, destIPAddr)
}

func (session *NATNEGSession) handleConnectReply(conn net.PacketConn, addr net.Addr, buffer []byte, moduleName string, version byte) {
	common.MaybeUnused(conn, addr, buffer, moduleName, version)

	// portType := buffer[0]
	clientIndex := buffer[1]
	// useGamePort := buffer[2]
	// localIPBytes := buffer[3:7]

	if client, exists := session.Clients[clientIndex]; exists {
		client.ConnectAck = true
	}
}
